

#include "sram.h"	  
#include "usart.h"	    
#include "delay.h"

int XmRamInit(void);
